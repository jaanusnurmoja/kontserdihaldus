<?php
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

include_once('localData.php');

class Crud
{

	protected function db()
	{
		$cnf = parse_ini_file('../config/connection.ini');
		$conn = new mysqli($cnf["servername"], $cnf["username"], $cnf["password"], $cnf["dbname"]);

		return $conn;
	}

    public function fields($data, $parent = null) {
        $toSubmit = array_filter($data, function ($item) {
            return !is_array($item);
        });
        $valTypes = [];
        foreach($toSubmit as $k => $v)
        {
            $valTypes[] = is_int($v) ? 'i' : (is_float($v) ? 'f' : 's');
            if ($parent != null && $k == $parent.'_id')
            {
                $v = "@last_id_$parent";
            }
        }
        $f = new stdClass;
        $f->names = implode(', ', array_keys($toSubmit));
        $f->toSubmit = $toSubmit;
        $f->values = "'" . implode("', '", array_values($toSubmit)) . "'";
        $f->arrValues = array_values($toSubmit);
        $f->prep = implode(', ', array_fill(0, count($toSubmit),'?'));
        $f->valTypes = implode($valTypes);
        return $f;
    }
    public function related($data) 
    {
        return array_filter($data, function ($item) {
            return is_array($item);
        });
    }
    public function submit($data, $table = 'kava', $parentTable = null, $parentTableId = null)
    {
        $fields = $this->fields($data, $parentTable)->names;
        //$valTypes = $this->fields($data)->valTypes;
        $values = $this->fields($data, $parentTable)->values;
        //list($vars);
        //$prep = $this->fields($data)->prep;
        if ($this->db()->connect_error) {
    die("Ühenduse loomine ei õnnestunud: " . $this->db()->connect_error);
}

        $sql = "INSERT INTO $table($fields) VALUES($values);
        SET @last_id_$table = 2;";
        //SELECT max(id) FROM $table;";
/*
        $stmt = $this->db()->prepare("INSERT INTO $table($fields) VALUES($prep)"); //Fetching all the records with input credentials
        $stmt->bind_param("$valTypes", implode(', ',$vars)); //Where s indicates string type. You can use i-integer, d-double
        var_dump($stmt);
        $stmt->execute();
        $result = $stmt->affected_rows;
        $stmt->close();
 */       
        if ($this->db()->query($sql) === TRUE) {
            echo "Uued read lisatud!";
            //$lastId = $this->db()->insert_id;
        } else {
            echo "Viga: " . $sql . "<br>" . $this->db()->error;
        }        

        if (!empty($this->related($data)))
        {
            foreach ($this->related($data) as $t => $d)
            {
                foreach ($d as $row)
                {
                    $this->submit($row, $t, $table);
                }
            }
        }

        $this->db()->close();

    }

}

?>