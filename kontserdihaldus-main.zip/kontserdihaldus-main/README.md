# kontserdikava
Loodud seoses veebiarendajate kursusega lõputöö jaoks. 

Sellega tegelevad Jaanus ja Oliver. Sissejuhatuseks toimub git'i lühikursus.

Muudatus 3s kord järjest juba

